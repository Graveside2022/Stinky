from flask import Flask, jsonify, request
import subprocess
import os
import signal
import psutil  # Install with: sudo apt install python3-psutil
import gps     # Install with: sudo apt install python3-gps
from flask_cors import CORS
import logging
import time
from datetime import datetime, timedelta
import requests  # For Kismet REST API calls
import json
import csv
import glob

# Set up logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='/var/log/webhook.log'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
PID_FILE = '/tmp/kismet_pids.txt'
SCRIPT_PID_FILE = '/tmp/kismet_script.pid'
WIGLETOTAK_SPECIFIC_PID_FILE = '/home/pi/tmp/wigletotak.specific.pid' # Specific PID for WigleToTAK
KISMET_LOG_PATH = '/var/log/kismet/kismet.log'
KISMET_API_URL = 'http://10.42.0.1:2501'
KISMET_AUTH = ('admin', 'admin')  # Default Kismet credentials

# Create tmp directory if it doesn't exist
os.makedirs('/home/pi/tmp', exist_ok=True)

def kill_process_tree(pid):
    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for child in children:
            try:
                logger.info(f"Killing child process {child.pid} ({child.name()})")
                child.kill()
            except Exception as e:
                logger.error(f"Error killing child process {child.pid}: {e}")
        try:
            logger.info(f"Killing parent process {pid} ({parent.name()})")
            parent.kill()
        except Exception as e:
            logger.error(f"Error killing parent process {pid}: {e}")
    except psutil.NoSuchProcess:
        logger.warning(f"Process {pid} no longer exists")
    except Exception as e:
        logger.error(f"Error killing process tree for {pid}: {e}")

def is_script_running():
    if not os.path.exists(SCRIPT_PID_FILE):
        return False
    try:
        with open(SCRIPT_PID_FILE, 'r') as f:
            pid = int(f.read().strip())
        return psutil.pid_exists(pid)
    except Exception:
        return False

def are_all_processes_running():
    if not os.path.exists(PID_FILE):
        return False
    try:
        with open(PID_FILE, 'r') as f:
            pids = [int(pid.strip()) for pid in f.readlines()]
        return all(psutil.pid_exists(pid) for pid in pids)
    except Exception:
        return False

@app.route('/run-script', methods=['POST'])
def run_script():
    logger.info("Received request to run script")
    
    # Check if script is already running and all processes are healthy
    if is_script_running() and are_all_processes_running():
        logger.info("Script is already running and healthy")
        return jsonify({'status': 'success', 'message': 'Script is already running'}), 200
    
    # If script is running but processes are not healthy, stop it
    if is_script_running():
        logger.info("Script is running but processes are not healthy, stopping...")
        try:
            with open(SCRIPT_PID_FILE, 'r') as f:
                main_pid = int(f.read().strip())
            if psutil.pid_exists(main_pid):
                kill_process_tree(main_pid)
        except Exception as e:
            logger.error(f"Error stopping unhealthy script: {e}")
    
    # First, try to stop any existing processes
    if os.path.exists(PID_FILE):
        try:
            logger.info("Found existing PID file, attempting cleanup")
            with open(PID_FILE, 'r') as f:
                pids = [int(pid.strip()) for pid in f.readlines()]
            for pid in pids:
                if psutil.pid_exists(pid):
                    logger.info(f"Killing existing process {pid}")
                    kill_process_tree(pid)
            os.remove(PID_FILE)
            logger.info("Successfully cleaned up existing processes")
        except Exception as e:
            logger.error(f"Error cleaning up existing processes: {e}")

    try:
        # Start the primary script
        logger.info("Starting new script instance")
        primary_script_path = '/home/pi/stinky/gps_kismet_wigle.sh'
        if not os.access(primary_script_path, os.X_OK):
            logger.error(f"Primary script {primary_script_path} is not executable")
            return jsonify({'status': 'error', 'message': 'Primary script is not executable'}), 500
            
        # Run the script as pi user
        proc = subprocess.Popen(
            ['sudo', '-u', 'pi', primary_script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )
        
        # Store the main script's PID
        try:
            with open(SCRIPT_PID_FILE, 'w') as f:
                f.write(str(proc.pid))
        except Exception as e:
            logger.warning(f"Could not write to SCRIPT_PID_FILE: {e}")
        
        logger.info(f"Started primary script with PID: {proc.pid}")
        
        # Wait for initial script startup
        logger.info("Waiting for initial script startup (30 seconds)...")
        time.sleep(30)
        
        # Check if the script is still running
        if not psutil.pid_exists(proc.pid):
            logger.error("Primary script failed to start properly")
            return jsonify({'status': 'error', 'message': 'Primary script failed to start properly'}), 500

        # Check Kismet startup with retries
        kismet_running = False
        max_kismet_retries = 12  # Increased retries
        kismet_retry_delay = 5   # Reduced delay between retries
        kismet_process = None
        
        for attempt in range(max_kismet_retries):
            logger.info(f"Checking for Kismet process (attempt {attempt + 1}/{max_kismet_retries})")
            
            # First check if Kismet process exists
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if 'kismet' in proc.info['name'].lower():
                        cmdline = ' '.join(proc.info['cmdline'] or [])
                        logger.info(f"Found Kismet process: {proc.info['pid']} - {cmdline[:100]}")
                        kismet_process = proc
                        kismet_running = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if kismet_running:
                logger.info("Kismet process found and running")
                break
            
            if attempt < max_kismet_retries - 1:
                logger.info(f"Kismet not found yet, waiting {kismet_retry_delay} seconds...")
                time.sleep(kismet_retry_delay)
        
        # Prepare status message
        status_messages = []
        status_messages.append("Script started successfully")
        
        if kismet_running:
            status_messages.append("Kismet is running")
        else:
            logger.warning("Kismet process not found, but script is running")
            status_messages.append("Kismet is starting up")
            
        # Check if cgps is running (optional - not critical)
        cgps_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if proc.info['name'] == 'cgps':
                cgps_running = True
                break
                
        if not cgps_running:
            logger.warning("cgps is not running (this is OK if no display is available)")
            
        # Check if WigleToTAK is running with retries
        wigle_running = False
        max_retries = 5
        retry_delay = 10
        
        for attempt in range(max_retries):
            logger.info(f"Checking for WigleToTAK process (attempt {attempt + 1}/{max_retries})")
            if os.path.exists(WIGLETOTAK_SPECIFIC_PID_FILE):
                try:
                    with open(WIGLETOTAK_SPECIFIC_PID_FILE, 'r') as pf:
                        wigle_pid_str = pf.read().strip()
                        if wigle_pid_str:
                            wigle_pid = int(wigle_pid_str)
                            if psutil.pid_exists(wigle_pid):
                                process = psutil.Process(wigle_pid)
                                cmdline = ' '.join(process.cmdline())
                                if 'WigleToTak2.py' in cmdline:
                                    logger.info(f"Confirmed WigleToTAK process {wigle_pid} is running")
                                    wigle_running = True
                                    break
                except Exception as e:
                    logger.warning(f"Error checking WigleToTAK (attempt {attempt + 1}): {e}")
            
            if not wigle_running and attempt < max_retries - 1:
                logger.info(f"WigleToTAK not ready yet, waiting {retry_delay} seconds...")
                time.sleep(retry_delay)
        
        if not wigle_running:
            logger.warning("WigleToTAK is not running, but continuing anyway")
        
        if cgps_running:
            status_messages.append("GPS display active")
        if wigle_running:
            status_messages.append("WigleToTAK running")
            
        status_message = " and ".join(status_messages)
        logger.info(f"All services started: {status_message}")
        return jsonify({'status': 'success', 'message': status_message}), 200
        
    except Exception as e:
        logger.error(f"Error starting script: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/stop-script', methods=['POST'])
def stop_script():
    logger.info("Received request to stop script")
    
    # Check if we have either the main script PID file or the general PID file
    script_running = is_script_running()
    pids_exist = os.path.exists(PID_FILE)
    
    if not script_running and not pids_exist:
        logger.info("No script process found and no PID file exists")
        return jsonify({'status': 'success', 'message': 'No running processes found'}), 200
    
    try:
        # Try to get the main script's PID if available
        main_pid = None
        if script_running and os.path.exists(SCRIPT_PID_FILE):
            with open(SCRIPT_PID_FILE, 'r') as f:
                try:
                    main_pid = int(f.read().strip())
                except ValueError:
                    logger.error(f"Invalid PID found in {SCRIPT_PID_FILE}")
                    main_pid = None
        
        # Kill the main script process and its children
        main_process_killed = False
        if main_pid is not None and psutil.pid_exists(main_pid):
            logger.info(f"Killing main script process {main_pid}")
            kill_process_tree(main_pid)
            main_process_killed = True
        elif main_pid is None and script_running:
            logger.warning(f"script_running is true, but couldn't get a valid main_pid from {SCRIPT_PID_FILE}")
        
        # Kill all related processes by name pattern
        logger.info("Killing all related processes by name...")
        process_patterns = ['kismet', 'cgps', 'WigleToTak', 'gps_kismet_wigle']
        killed_any = False
        for pattern in process_patterns:
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = ' '.join(proc.info['cmdline'] or [])
                    if pattern in cmdline and proc.info['pid'] != os.getpid():
                        logger.info(f"Killing {pattern} process: {proc.info['pid']} - {cmdline[:100]}")
                        proc.kill()
                        killed_any = True
                except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                    pass
                except Exception as e:
                    logger.error(f"Error checking/killing process: {e}")
        
        # Then handle any remaining processes from the PID file
        pid_file_processes_killed = False
        if os.path.exists(PID_FILE):
            with open(PID_FILE, 'r') as f:
                pids = [int(pid.strip()) for pid in f.readlines()]
            
            for pid in pids:
                if psutil.pid_exists(pid):
                    try:
                        logger.info(f"Killing process {pid} from PID file")
                        kill_process_tree(pid)
                        pid_file_processes_killed = True
                    except Exception as e:
                        logger.error(f"Error killing process {pid}: {e}")
                        try:
                            os.kill(pid, signal.SIGKILL)
                            logger.info(f"Used SIGKILL on process {pid}")
                            pid_file_processes_killed = True
                        except Exception as e:
                            logger.error(f"Failed to kill process {pid} with SIGKILL: {e}")
        
        # Clean up PID files
        pid_files_cleaned = False
        try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
            logger.info("Removed PID file")
        if os.path.exists(SCRIPT_PID_FILE):
            os.remove(SCRIPT_PID_FILE)
            logger.info("Removed script PID file")
            pid_files_cleaned = True
        except Exception as e:
            logger.error(f"Failed to remove PID files: {e}")

        # Restart gpsd to ensure fresh GPS data
        gpsd_restarted = False
        try:
            logger.info("Restarting gpsd service...")
            subprocess.run(['sudo', 'systemctl', 'restart', 'gpsd'], check=True)
            logger.info("Successfully restarted gpsd service")
            gpsd_restarted = True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to restart gpsd service: {e}")
        except Exception as e:
            logger.error(f"Unexpected error while restarting gpsd: {e}")

        # Bring wlan2 back up
        wlan2_restored = False
        try:
            logger.info("Bringing wlan2 back up...")
            # First, ensure the interface is down
            subprocess.run(['sudo', 'ip', 'link', 'set', 'wlan2', 'down'], check=True)
            # Remove monitor mode
            subprocess.run(['sudo', 'iw', 'dev', 'wlan2', 'set', 'type', 'managed'], check=True)
            # Bring the interface back up
            subprocess.run(['sudo', 'ip', 'link', 'set', 'wlan2', 'up'], check=True)
            logger.info("Successfully brought wlan2 back up")
            wlan2_restored = True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to bring wlan2 back up: {e}")
        except Exception as e:
            logger.error(f"Unexpected error while bringing wlan2 back up: {e}")
            
        # Check if any processes were actually killed
        if not (main_process_killed or killed_any or pid_file_processes_killed):
            logger.warning("No processes were found to kill")
            return jsonify({'status': 'warning', 'message': 'No running processes found to stop'}), 200
            
        # Prepare status message
        status_messages = []
        if main_process_killed:
            status_messages.append("Main script stopped")
        if killed_any:
            status_messages.append("Related processes stopped")
        if pid_file_processes_killed:
            status_messages.append("PID file processes stopped")
        if pid_files_cleaned:
            status_messages.append("PID files cleaned")
        if gpsd_restarted:
            status_messages.append("GPS service restarted")
        if wlan2_restored:
            status_messages.append("Network interface restored")
            
        status_message = " and ".join(status_messages)
        logger.info(f"Successfully stopped all processes: {status_message}")
        return jsonify({'status': 'success', 'message': status_message}), 200
        
    except Exception as e:
        logger.error(f"Error in stop_script: {e}")
        # Always try to remove the PID files
        try:
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)
            if os.path.exists(SCRIPT_PID_FILE):
                os.remove(SCRIPT_PID_FILE)
        except Exception as e:
            logger.error(f"Failed to remove PID files: {e}")
        return jsonify({'status': 'error', 'message': f'Error stopping script: {str(e)}'}), 500

@app.route('/info', methods=['GET'])
def info():
    # Get user IP
    user_ip = request.remote_addr
    logger.info(f"Info request from IP: {user_ip}")
    
    # Get GPS data using gpspipe
    gpsd_data = {
        'lat': None,
        'lon': None,
        'alt': None,
        'mode': 0,
        'time': None,
        'speed': None,
        'track': None,
        'status': 'No Fix'
    }
    
    try:
        # First check if gpsd is running
        gpsd_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if 'gpsd' in proc.info['name'].lower():
                gpsd_running = True
                break
        
        if not gpsd_running:
            logger.warning("gpsd is not running")
            return jsonify({
                'gps': gpsd_data,
                'kismet': "Not Running",
                'wigle': "Not Running",
                'ip': user_ip
            })
        
        # Use gpspipe to get GPS data
        logger.info("Attempting to get GPS data using gpspipe...")
        process = subprocess.Popen(['gpspipe', '-w', '-n', '10'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(timeout=10)
        
        if stderr:
            logger.error(f"gpspipe error: {stderr.decode()}")
        
        if stdout:
            try:
                # Split the output into individual JSON objects
                gps_data_list = stdout.decode().strip().split('\n')
                logger.info(f"Received {len(gps_data_list)} GPS data objects")
                
                # Look for TPV data
                tpv_data = None
                for data_str in gps_data_list:
                    try:
                        data = json.loads(data_str)
                        if isinstance(data, dict) and data.get('class') == 'TPV':
                            tpv_data = data
                            break
                    except json.JSONDecodeError:
                        continue
                
                if tpv_data:
                    logger.info(f"Found TPV data: {tpv_data}")
                    mode = tpv_data.get('mode', 0)
                    lat = tpv_data.get('lat')
                    lon = tpv_data.get('lon')
                    alt = tpv_data.get('alt')
                    time_str = tpv_data.get('time')
                    speed = tpv_data.get('speed')
                    track = tpv_data.get('track')
                    
                    logger.info(f"GPS Values - Lat: {lat}, Lon: {lon}, Alt: {alt}, Time: {time_str}, Speed: {speed}, Track: {track}")
                    
                    # Update GPS data
                    gpsd_data = {
                        'lat': lat,
                        'lon': lon,
                        'alt': alt,
                        'mode': mode,
                        'time': time_str,
                        'speed': speed,
                        'track': track,
                        'status': '3D Fix' if mode == 3 else '2D Fix' if mode == 2 else 'No Fix'
                    }
                    
                    # If we have valid coordinates, consider it a fix
                    if lat is not None and lon is not None:
                        gpsd_data['status'] = '3D Fix' if alt is not None else '2D Fix'
                        logger.info(f"Got GPS fix: {gpsd_data}")
                else:
                    logger.warning("No TPV data found in GPS output")
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing GPS JSON: {e}")
            except Exception as e:
                logger.error(f"Error processing GPS data: {e}")
    except subprocess.TimeoutExpired:
        logger.error("Timeout waiting for GPS data")
    except Exception as e:
        logger.error(f"Error getting GPS data: {e}")
    
    # Get Kismet status
    kismet_status = "Not Running"
    try:
        # Check if Kismet process is running
        kismet_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if 'kismet' in proc.info['name'].lower():
                kismet_running = True
                break
        
        if kismet_running:
            # Try to connect to Kismet API
            response = requests.get(
                f"{KISMET_API_URL}/system/status.json",
                auth=KISMET_AUTH,
                timeout=2,
                headers={'Accept': 'application/json'}
            )
            if response.status_code == 200:
                kismet_status = "Running"
                logger.info("Kismet API is accessible")
            else:
                logger.warning(f"Kismet process running but API returned status {response.status_code}")
        else:
            logger.warning("Kismet process not found")
    except Exception as e:
        logger.error(f"Error checking Kismet status: {e}")
    
    # Get WigleToTAK status
    wigle_status = "Not Running"
    if os.path.exists(WIGLETOTAK_SPECIFIC_PID_FILE):
        try:
            with open(WIGLETOTAK_SPECIFIC_PID_FILE, 'r') as f:
                pid = int(f.read().strip())
            if psutil.pid_exists(pid):
                wigle_status = "Running"
        except:
            pass
    
    logger.info(f"Returning data: GPS={gpsd_data}, Kismet={kismet_status}, Wigle={wigle_status}")
    return jsonify({
        'gps': gpsd_data,
        'kismet': kismet_status,
        'wigle': wigle_status,
        'ip': user_ip
    })

@app.route('/script-status', methods=['GET'])
def script_status():
    logger.info("Checking script status")
    
    # Check if main script is running
    script_running = is_script_running()
    
    # Check Kismet status - try both localhost and the configured IP
    kismet_running = False
    kismet_api_responding = False
    
    # First check if Kismet process exists
    for proc in psutil.process_iter(['pid', 'name']):
        if 'kismet' in proc.info['name'].lower():
            kismet_running = True
            logger.info(f"Found Kismet process: {proc.info}")
            break
    
    # If Kismet process is running, try to connect to its API
    if kismet_running:
        # Try both localhost and the configured IP
        kismet_urls = [
            'http://localhost:2501',
            'http://127.0.0.1:2501',
            KISMET_API_URL
        ]
        
        for url in kismet_urls:
            try:
                logger.info(f"Attempting to connect to Kismet API at {url}")
                response = requests.get(f"{url}/system/status.json", auth=KISMET_AUTH, timeout=2)
                if response.ok:
                    kismet_api_responding = True
                    logger.info(f"Successfully connected to Kismet API at {url}")
                    break
            except Exception as e:
                logger.warning(f"Could not connect to Kismet API at {url}: {e}")
                continue
    
    # Check WigletoTak status
    wigle_running = False
    if os.path.exists(WIGLETOTAK_SPECIFIC_PID_FILE):
        try:
            with open(WIGLETOTAK_SPECIFIC_PID_FILE, 'r') as pf:
                wigle_pid_str = pf.read().strip()
                if wigle_pid_str:
                    wigle_pid = int(wigle_pid_str)
                    if psutil.pid_exists(wigle_pid):
                        process = psutil.Process(wigle_pid)
                        cmdline = ' '.join(process.cmdline())
                        if 'WigleToTak2.py' in cmdline:
                            wigle_running = True
        except Exception as e:
            logger.error(f"Error checking WigletoTak status: {e}")
    
    # Prepare status message
    status_messages = []
    if script_running:
        status_messages.append("Script is running")
        if kismet_running:
            if kismet_api_responding:
                status_messages.append("Kismet is running")
            else:
                status_messages.append("Kismet is running (API not responding)")
        else:
            status_messages.append("Kismet is starting up")
        if wigle_running:
            status_messages.append("WigleToTAK is running")
    else:
        status_messages.append("Script is stopped")
    
    return jsonify({
        'running': script_running,
        'message': " and ".join(status_messages),
        'kismet_running': kismet_running,
        'kismet_api_responding': kismet_api_responding,
        'wigle_running': wigle_running
    })

def get_latest_kismet_csv():
    try:
        # Get the most recent CSV file from the kismet_ops directory
        csv_files = glob.glob('/home/pi/kismet_ops/*.csv')
        if not csv_files:
            logger.warning("No Kismet CSV files found in /home/pi/kismet_ops")
            return None
            
        # Log all found CSV files with their timestamps
        logger.info("Found CSV files:")
        for file in csv_files:
            ctime = datetime.fromtimestamp(os.path.getctime(file))
            logger.info(f"  - {file} (Created: {ctime})")
            
        # Get the most recent file
        latest_file = max(csv_files, key=os.path.getctime)
        latest_time = datetime.fromtimestamp(os.path.getctime(latest_file))
        logger.info(f"Selected latest file: {latest_file} (Created: {latest_time})")
        
        # Verify the file is not too old (e.g., not older than 1 hour)
        if datetime.now() - latest_time > timedelta(hours=1):
            logger.warning(f"Latest CSV file is older than 1 hour: {latest_file}")
            return None
            
        # Verify the file has content
        if os.path.getsize(latest_file) == 0:
            logger.warning(f"Latest CSV file is empty: {latest_file}")
            return None
            
        devices = []
        networks = set()
        recent_devices = []
        
        with open(latest_file, 'r') as f:
            # Read first line to verify CSV format
            header = f.readline().strip()
            if not header:
                logger.error("CSV file has no header")
                return None
                
            # Reset file pointer to start
            f.seek(0)
            csv_reader = csv.DictReader(f)
            
            # Verify required columns exist
            required_columns = ['type', 'mac', 'name', 'channel']
            missing_columns = [col for col in required_columns if col not in csv_reader.fieldnames]
            if missing_columns:
                logger.error(f"CSV file missing required columns: {missing_columns}")
                return None
                
            logger.info(f"Processing CSV file with columns: {csv_reader.fieldnames}")
            
            for row in csv_reader:
                try:
                    # Extract device info from CSV
                    device_type = row.get('type', 'Unknown')
                    device_mac = row.get('mac', 'Unknown')
                    device_name = row.get('name', 'Unknown')
                    device_channel = row.get('channel', 'Unknown')
                    device_signal = row.get('signal', 'Unknown')
                    device_first_seen = row.get('first_seen', 'Unknown')
                    device_last_seen = row.get('last_seen', 'Unknown')
                    
                    # Add to networks count if it's a network device
                    if device_type in ['Wi-Fi AP', 'Wi-Fi Client']:
                        networks.add(device_mac)
                    
                    # Add to devices list
                    devices.append({
                        'name': device_name,
                        'type': device_type,
                        'mac': device_mac,
                        'channel': device_channel,
                        'signal': device_signal,
                        'first_seen': device_first_seen,
                        'last_seen': device_last_seen
                    })
                    
                    # Add to recent devices (last 5)
                    if len(recent_devices) < 5:
                        recent_devices.append({
                            'name': device_name or device_mac,
                            'type': device_type,
                            'channel': device_channel
                        })
                        
                except Exception as e:
                    logger.error(f"Error processing CSV row: {e}")
                    continue
            
            logger.info(f"Successfully processed {len(devices)} devices from CSV file")
                    
        return {
            'devices_count': len(devices),
            'networks_count': len(networks),
            'recent_devices': recent_devices,
            'feed_items': [{
                'type': 'Device',
                'message': f"{device['name']} ({device['type']}) - Channel {device['channel']}"
            } for device in recent_devices],
            'last_update': datetime.now().strftime('%H:%M:%S')
        }
    except Exception as e:
        logger.error(f"Error reading Kismet CSV file: {e}")
        return None

@app.route('/kismet-data', methods=['GET'])
def kismet_data():
    try:
        logger.info("Attempting to fetch Kismet data...")
        
        # First try to get data from CSV file
        csv_data = get_latest_kismet_csv()
        if csv_data:
            logger.info("Successfully read data from Kismet CSV file")
            return jsonify(csv_data)
            
        # If CSV data is not available, fall back to API
        kismet_running = False
        for proc in psutil.process_iter(['pid', 'name']):
            if 'kismet' in proc.info['name'].lower():
                kismet_running = True
                logger.info(f"Found Kismet process: {proc.info}")
                break
        
        if not kismet_running:
            logger.error("Kismet process not found")
            return jsonify({
                'error': 'Kismet is not running',
                'devices_count': 0,
                'networks_count': 0,
                'recent_devices': [],
                'feed_items': [],
                'last_update': datetime.now().strftime('%H:%M:%S')
            }), 200

        # Try to get devices from Kismet REST API with authentication
        api_url = f"{KISMET_API_URL}/devices/views/all_devices.json"
        logger.info(f"Attempting to connect to Kismet API at: {api_url}")
        
        try:
            # First try with authentication
            response = requests.get(
                api_url,
                auth=KISMET_AUTH,
                timeout=5,
                headers={'Accept': 'application/json'}
            )
            logger.info(f"Kismet API response status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"Successfully connected to Kismet API")
                logger.info(f"Received Kismet data: {json.dumps(data)[:200]}...")
                
                devices = []
                networks = set()
                recent_devices = []
                
                if 'devices' in data:
                    for device in data['devices']:
                        try:
                            # Extract device info
                            device_info = device.get('kismet', {}).get('device', {}).get('base', {})
                            device_type = device_info.get('type', 'Unknown')
                            device_mac = device_info.get('mac', 'Unknown')
                            device_name = device_info.get('name', 'Unknown')
                            device_channel = device_info.get('channel', 'Unknown')
                            device_signal = device_info.get('signal', 'Unknown')
                            device_first_seen = device_info.get('first_time', 'Unknown')
                            device_last_seen = device_info.get('last_time', 'Unknown')
                            
                            # Add to networks count if it's a network device
                            if device_type in ['Wi-Fi AP', 'Wi-Fi Client']:
                                networks.add(device_mac)
                            
                            # Add to devices list
                            devices.append({
                                'name': device_name,
                                'type': device_type,
                                'mac': device_mac,
                                'channel': device_channel,
                                'signal': device_signal,
                                'first_seen': device_first_seen,
                                'last_seen': device_last_seen
                            })
                            
                            # Add to recent devices (last 5)
                            if len(recent_devices) < 5:
                                recent_devices.append({
                                    'name': device_name or device_mac,
                                    'type': device_type,
                                    'channel': device_channel
                                })
                                
                        except Exception as e:
                            logger.error(f"Error processing device: {e}")
                            continue
                
                # Create feed items for recent activity
                feed_items = []
                for device in recent_devices:
                    feed_items.append({
                        'type': 'Device',
                        'message': f"{device['name']} ({device['type']}) - Channel {device['channel']}"
                    })
                
                response_data = {
                    'devices_count': len(devices),
                    'networks_count': len(networks),
                    'recent_devices': recent_devices,
                    'feed_items': feed_items,
                    'last_update': datetime.now().strftime('%H:%M:%S')
                }
                logger.info(f"Returning Kismet data: {json.dumps(response_data)[:200]}...")
                return jsonify(response_data)
            else:
                logger.error(f"Failed to get data from Kismet: {response.status_code}")
                logger.error(f"Response content: {response.text[:200]}")
                return jsonify({
                    'error': f'Failed to get data from Kismet (Status: {response.status_code})',
                    'status_code': response.status_code,
                    'devices_count': 0,
                    'networks_count': 0,
                    'recent_devices': [],
                    'feed_items': [],
                    'last_update': datetime.now().strftime('%H:%M:%S')
                }), 200
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error to Kismet API: {e}")
            # Try to get more information about the connection
            try:
                import socket
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                result = sock.connect_ex(('localhost', 2501))
                logger.error(f"Socket connection test result: {result}")
                sock.close()
            except Exception as sock_error:
                logger.error(f"Socket test error: {sock_error}")
            
            return jsonify({
                'error': 'Could not connect to Kismet API - Connection refused',
                'devices_count': 0,
                'networks_count': 0,
                'recent_devices': [],
                'feed_items': [],
                'last_update': datetime.now().strftime('%H:%M:%S')
            }), 200
    except Exception as e:
        logger.error(f"Error getting Kismet data: {e}")
        return jsonify({
            'error': str(e),
            'devices_count': 0,
            'networks_count': 0,
            'recent_devices': [],
            'feed_items': [],
            'last_update': datetime.now().strftime('%H:%M:%S')
        }), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

