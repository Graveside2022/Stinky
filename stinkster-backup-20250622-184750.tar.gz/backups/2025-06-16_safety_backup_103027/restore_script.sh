#\!/bin/bash
# Restore Script for Kismet Operations Backup
# Created: 2025-06-16T10:30:27Z

echo "=== Kismet Operations Restore Script ==="
echo "This script will restore the backed up state"
echo ""

# Check if running from backup directory
if [ \! -f "backup_metadata.txt" ]; then
    echo "ERROR: Must run from backup directory containing backup_metadata.txt"
    exit 1
fi

echo "Are you sure you want to restore? This will:"
echo "1. Stop current Node.js kismet-operations service"
echo "2. Restore the kismet-operations directory"
echo "3. Restore configuration files"
echo "4. Restore Python webhook service if needed"
echo ""
read -p "Continue? (y/N): " confirm

if [ "$confirm" \!= "y" ]; then
    echo "Restore cancelled"
    exit 0
fi

# Stop current services
echo "Stopping current services..."
pkill -f "node.*server.js" || true
sleep 2

# Restore kismet-operations
echo "Restoring kismet-operations directory..."
rm -rf ../../../src/nodejs/kismet-operations
cp -r kismet-operations ../../../src/nodejs/

# Restore configs
echo "Restoring configuration files..."
[ -f "configs/config.py" ] && cp configs/config.py ../../../
[ -f "configs/docker-compose.yml" ] && cp configs/docker-compose.yml ../../../
[ -d "configs/config" ] && cp -r configs/config ../../../
[ -f "configs/.env" ] && cp configs/.env ../../../

# Restore Python services if they were removed
if [ -d "python_services/webhook.py" ] && [ \! -f "/home/pi/web/webhook.py" ]; then
    echo "Restoring Python webhook service..."
    cp python_services/webhook.py /home/pi/web/
fi

echo ""
echo "Restore complete\! Next steps:"
echo "1. Restart Node.js service: cd src/nodejs/kismet-operations && npm start"
echo "2. Verify webhook functionality"
echo "3. Check service status with: ps aux | grep -E 'node|webhook'"

