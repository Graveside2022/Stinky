# Current Functionality to Mobile-First Mapping

## Core Functionality Components

### 1. Navigation System

#### Current Implementation
```javascript
// From kismet-operations.js
document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        // Tab switching logic
    });
});
```

#### Mobile-First Transformation
```javascript
// Enhanced with touch support
const tabSystem = {
    init() {
        this.addTouchSupport();
        this.addSwipeGestures();
        this.setupResponsiveNav();
    },
    
    addTouchSupport() {
        // Larger touch targets on mobile
        // Prevent accidental taps
        // Add haptic feedback where supported
    }
};
```

### 2. Service Control Panel

#### Current Structure (ATAK Tab)
```html
<!-- 4 button grid -->
<div class="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
    <button onclick="startService('gps')">Start GPS</button>
    <button onclick="startService('kismet')">Start Kismet</button>
    <button onclick="startService('wigle')">Start Wigle</button>
    <button onclick="stopAllServices()">Stop All</button>
</div>
```

#### Mobile-First Redesign
```html
<!-- Stack by default, grid on larger screens -->
<div class="service-controls">
    <button class="service-btn" data-service="gps">
        <span class="service-icon">📍</span>
        <span class="service-label">GPS</span>
        <span class="service-status" data-status="inactive"></span>
    </button>
    <!-- More buttons... -->
</div>
```

```css
/* Mobile base */
.service-controls {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.service-btn {
    display: flex;
    align-items: center;
    padding: 1rem;
    width: 100%;
}

/* Tablet and up */
@media (min-width: 768px) {
    .service-controls {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Desktop */
@media (min-width: 1024px) {
    .service-controls {
        grid-template-columns: repeat(4, 1fr);
    }
}
```

### 3. Status Display Components

#### Current Implementation
```html
<div class="glass rounded-cyber-lg p-4 md:p-6">
    <h3>Service Status</h3>
    <div class="space-y-2 md:space-y-3">
        <!-- Status items -->
    </div>
</div>
```

#### Mobile-First Component
```css
/* Status card - mobile optimized */
.status-card {
    background: var(--glass-bg);
    border-radius: var(--radius-base);
    padding: var(--spacing-md);
    margin-bottom: var(--spacing-md);
}

.status-item {
    display: flex;
    justify-content: space-between;
    padding: var(--spacing-sm);
    margin-bottom: var(--spacing-xs);
}

/* Progressive enhancement */
@media (min-width: 768px) {
    .status-card {
        padding: var(--spacing-lg);
    }
    
    .status-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: var(--spacing-lg);
    }
}
```

### 4. Iframe Container (Kismet View)

#### Current Approach
```html
<iframe src="http://localhost:2501" 
        class="w-full h-[500px] md:h-[600px]">
</iframe>
```

#### Mobile-First Iframe Management
```javascript
class ResponsiveIframe {
    constructor(container) {
        this.container = container;
        this.iframe = container.querySelector('iframe');
        this.setupResponsive();
    }
    
    setupResponsive() {
        // Calculate optimal height based on viewport
        const updateHeight = () => {
            const vh = window.innerHeight;
            const headerHeight = 120; // Dynamic calculation
            const optimalHeight = vh - headerHeight;
            
            this.iframe.style.height = `${Math.max(400, optimalHeight)}px`;
        };
        
        // Update on resize/orientation change
        window.addEventListener('resize', debounce(updateHeight, 100));
        window.addEventListener('orientationchange', updateHeight);
        
        updateHeight();
    }
}
```

### 5. Tab Minimization System

#### Current Implementation
- Tabs minimize to a bar at top
- Fixed positioning issues on mobile

#### Mobile-First Approach
```javascript
class TabManager {
    constructor() {
        this.minimizedTabs = new Map();
        this.setupMobileOptimizations();
    }
    
    minimizeTab(tabId, title) {
        if (this.isMobile()) {
            // On mobile, use bottom sheet pattern
            this.createBottomSheet(tabId, title);
        } else {
            // Desktop uses top bar
            this.createMinimizedTab(tabId, title);
        }
    }
    
    isMobile() {
        return window.innerWidth < 768;
    }
}
```

### 6. Form Inputs (Wigle Tab)

#### Current Forms
```html
<input type="text" class="input-cyber text-sm md:text-base" 
       placeholder="239.2.3.1" value="239.2.3.1">
```

#### Mobile-Optimized Forms
```css
/* Base input - touch friendly */
.form-input {
    width: 100%;
    padding: 0.75rem;
    font-size: 1rem; /* 16px prevents zoom on iOS */
    border: 1px solid var(--border-color);
    border-radius: var(--radius-base);
    background: var(--input-bg);
    color: var(--text-primary);
    -webkit-appearance: none; /* Remove iOS styling */
}

/* Focus state for touch */
.form-input:focus {
    outline: 3px solid var(--focus-color);
    outline-offset: 2px;
}

/* Desktop enhancement */
@media (min-width: 768px) {
    .form-input {
        padding: 0.5rem 0.75rem;
        font-size: 0.875rem;
    }
}
```

### 7. Data Tables (Device List)

#### Current Table
```html
<div class="overflow-x-auto">
    <table class="w-full min-w-[500px]">
        <!-- Table content -->
    </table>
</div>
```

#### Mobile-First Data Display
```javascript
class ResponsiveDataDisplay {
    constructor(data) {
        this.data = data;
        this.render();
    }
    
    render() {
        if (window.innerWidth < 768) {
            this.renderCards();
        } else {
            this.renderTable();
        }
    }
    
    renderCards() {
        // Card layout for mobile
        return `
            <div class="device-cards">
                ${this.data.map(device => `
                    <div class="device-card">
                        <div class="device-header">
                            <span class="device-name">${device.name}</span>
                            <span class="device-signal">${device.signal}</span>
                        </div>
                        <div class="device-details">
                            <span class="device-type">${device.type}</span>
                            <span class="device-time">${device.lastSeen}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    renderTable() {
        // Traditional table for desktop
        // ... existing table code
    }
}
```

### 8. WebSocket Connection Management

#### Mobile Considerations
```javascript
class MobileWebSocket {
    constructor(url) {
        this.url = url;
        this.reconnectAttempts = 0;
        this.setupMobileHandling();
    }
    
    setupMobileHandling() {
        // Handle connection on app resume
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.ws.readyState !== WebSocket.OPEN) {
                this.reconnect();
            }
        });
        
        // Battery-aware connection management
        if ('getBattery' in navigator) {
            navigator.getBattery().then(battery => {
                battery.addEventListener('levelchange', () => {
                    if (battery.level < 0.15) {
                        this.reduceUpdateFrequency();
                    }
                });
            });
        }
    }
}
```

## Responsive Utility Classes

### Current Tailwind Usage
- `text-sm md:text-base`
- `p-4 md:p-6`
- `hidden md:block`

### Mobile-First Utilities
```css
/* Text sizing */
.text-responsive {
    font-size: var(--text-base);
}

/* Spacing */
.p-responsive {
    padding: var(--spacing-md);
}

/* Visibility */
.desktop-only {
    display: none;
}

@media (min-width: 768px) {
    .desktop-only {
        display: block;
    }
    
    .mobile-only {
        display: none;
    }
}
```

## Performance Optimizations

### 1. Lazy Loading
```javascript
// Load heavy components only when needed
const lazyLoadIframe = (container) => {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const iframe = entry.target;
                iframe.src = iframe.dataset.src;
                observer.unobserve(iframe);
            }
        });
    });
    
    observer.observe(container.querySelector('iframe'));
};
```

### 2. Touch Event Optimization
```javascript
// Prevent 300ms delay on mobile
let touchTimeout;
element.addEventListener('touchstart', (e) => {
    touchTimeout = setTimeout(() => {
        // Handle long press
    }, 500);
});

element.addEventListener('touchend', (e) => {
    clearTimeout(touchTimeout);
    // Immediate response
    e.preventDefault();
    handleClick(e);
});
```

### 3. Reduced Motion Support
```css
@media (prefers-reduced-motion: reduce) {
    * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
}
```

## Migration Checklist

- [ ] Replace inline media queries with mobile-first CSS
- [ ] Update button components for touch targets
- [ ] Implement responsive data displays
- [ ] Add touch event handlers
- [ ] Optimize iframe loading
- [ ] Test on various mobile devices
- [ ] Add progressive enhancement
- [ ] Implement offline support
- [ ] Add PWA capabilities
- [ ] Optimize performance metrics