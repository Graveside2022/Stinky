# Mobile-First Structure Analysis

## Current vs. Target Architecture

### 1. Layout Structure

#### Current Implementation (index.html & index_mobile.html)
- **Desktop-First Approach**: Uses media queries to adapt DOWN to mobile
- **Fixed Breakpoints**: 768px, 932px (landscape)
- **Inline Styles**: Mobile overrides in `<style>` tags
- **Grid System**: Uses Tailwind's grid with responsive modifiers

#### Target Mobile-First Structure
```css
/* Base styles for mobile */
.container {
    padding: 0.75rem;
    max-width: 100%;
}

/* Tablet and up */
@media (min-width: 768px) {
    .container {
        padding: 1rem;
        max-width: 768px;
    }
}

/* Desktop */
@media (min-width: 1024px) {
    .container {
        padding: 1.5rem;
        max-width: 1280px;
    }
}
```

### 2. CSS Approach Analysis

#### Current Approach
- **Multiple CSS files**: 
  - `kismet-operations.css` (main styles)
  - `common-styles.css`
  - `styles.css` (Tailwind output)
  - `spectrum.css`
- **Inline media queries** for mobile fixes
- **!important overrides** for mobile responsiveness

#### Mobile-First CSS Strategy
```css
/* Mobile base - no media query needed */
.grid-item {
    padding: 1rem;
    margin-bottom: 1rem;
    border: 1px solid var(--border-color);
}

/* Enhance for larger screens */
@media (min-width: 768px) {
    .grid-item {
        padding: 1.5rem;
        margin-bottom: 1.5rem;
    }
}

@media (min-width: 1024px) {
    .grid-item {
        padding: 2rem;
        margin-bottom: 2rem;
    }
}
```

### 3. Grid-Item Component Structure

#### Current Implementation
```html
<div class="grid-item relative" id="kismet-container">
    <div class="flex items-center justify-between mb-3 md:mb-4">
        <h2 class="text-xl md:text-2xl font-bold text-cyber-blue">Title</h2>
        <button class="control-button-small">...</button>
    </div>
    <iframe src="..." class="w-full h-[500px] md:h-[600px]"></iframe>
</div>
```

#### Target Component Structure
```html
<div class="grid-item">
    <header class="grid-item-header">
        <h2 class="grid-item-title">Title</h2>
        <div class="grid-item-controls">
            <button class="btn-minimize">-</button>
        </div>
    </header>
    <div class="grid-item-content">
        <!-- Content goes here -->
    </div>
</div>
```

### 4. Button Styling Patterns

#### Current Button Classes
- `btn-cyber` - Main button style with variants
- `control-button-small` - Minimize/control buttons
- `nav-tab` - Navigation tabs
- Color variants using Tailwind utilities

#### Mobile-First Button Approach
```css
/* Base button - mobile optimized */
.btn {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    border-radius: 0.25rem;
    transition: all 0.2s;
}

/* Larger screens get bigger buttons */
@media (min-width: 768px) {
    .btn {
        padding: 0.75rem 1.5rem;
        font-size: 1rem;
    }
}
```

### 5. Responsive Behavior Patterns

#### Navigation
- **Current**: Horizontal scroll on mobile with `overflow-x-auto`
- **Target**: Same approach but with mobile-first sizing

#### Service Controls (ATAK Tab)
- **Current**: 2x2 grid on mobile, 4 columns on desktop
- **Target**: Stack vertically by default, grid on larger screens

#### Tables (Device List)
- **Current**: Horizontal scroll wrapper
- **Target**: Consider card layout for mobile, table for desktop

#### Iframes
- **Current**: Fixed heights with media query overrides
- **Target**: Dynamic height based on viewport

## Functionality Mapping

### 1. Tab System
- **Files**: `kismet-operations.js`
- **Functions**: Tab switching, minimize/restore
- **Mobile considerations**: Touch events, swipe gestures

### 2. Service Management
- **Endpoints**: `/api/webhook/scripts/*`
- **WebSocket**: Real-time status updates
- **Mobile needs**: Larger touch targets, status indicators

### 3. Resize Functionality
- **Current**: Resize handles on all sides
- **Mobile**: Disabled via CSS
- **Target**: Progressive enhancement - only on desktop

### 4. Notifications/Overlays
- **Current**: Fixed positioning with z-index management
- **Mobile**: Adjust for safe areas, smaller screens

## Implementation Strategy

### Phase 1: CSS Architecture
1. Create new `mobile-first.css` with base mobile styles
2. Add progressive enhancement media queries
3. Define CSS custom properties for responsive values

### Phase 2: Component Refactoring
1. Update grid-item structure
2. Standardize button components
3. Create responsive table/card switcher

### Phase 3: JavaScript Updates
1. Add touch event support
2. Implement viewport-aware sizing
3. Optimize for mobile performance

### Phase 4: Testing & Optimization
1. Test on various devices
2. Performance profiling
3. Accessibility improvements

## CSS Variable System
```css
:root {
    /* Mobile-first spacing */
    --spacing-xs: 0.25rem;
    --spacing-sm: 0.5rem;
    --spacing-md: 1rem;
    --spacing-lg: 1.5rem;
    --spacing-xl: 2rem;
    
    /* Mobile-first typography */
    --text-xs: 0.75rem;
    --text-sm: 0.875rem;
    --text-base: 1rem;
    --text-lg: 1.125rem;
    --text-xl: 1.25rem;
}

/* Enhance for larger screens */
@media (min-width: 768px) {
    :root {
        --text-base: 1.125rem;
        --text-lg: 1.25rem;
        --text-xl: 1.5rem;
    }
}
```

## Breakpoint Strategy
- **Base (Mobile)**: 0-767px
- **Tablet**: 768px-1023px  
- **Desktop**: 1024px-1279px
- **Large Desktop**: 1280px+

## Component Library Needs
1. Responsive navigation component
2. Mobile-optimized forms
3. Touch-friendly controls
4. Progressive disclosure patterns
5. Responsive data display (table/card switcher)